﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace ForagingJoe
{
    public class PlatformSprite : Sprite
    {
        public const int Width = 32;
        public const int Height = 32;

        public const string _platformBitmap = @"graphics\Platform.bmp";

        public PlatformSprite(GameState gameState, float x, float y)
            : base(gameState, x, y, _platformBitmap)
        {
        }
    }

    public class Platform : GameObject
    {
        //private static PointF _initialDirection = new PointF(-1, 0);
        private static PointF _initialDirection = new PointF(0, 0);
        private const PlatformMovement _initialMovement = PlatformMovement.Left;
        //private const int _startY = 55;
        private PointF _direction;
        private float _speed = 100;
        private PlatformMovement _movement = _initialMovement;
        private List<Sprite> _platforms = new List<Sprite>();
        private GameState _gameState;

        public Platform(GameState gameState)
        {
            _gameState = gameState;


            CreatePlatforms();
        }

        public void CreatePlatforms()
        {
            _platforms.Clear();

            _platforms.Add(new PlatformSprite(_gameState, _gameState.GameArea.Width / 2 - 20, _gameState.GameArea.Height - 125));

            _direction = _initialDirection;
            //_speed = _initialSpeed;
            _movement = _initialMovement;
        }

        public override void Update(double gameTime, double elapsedTime)
        {
            PointF minLocation = new PointF(Single.MaxValue, Single.MaxValue);
            PointF maxLocation = new PointF(Single.MinValue, Single.MinValue);

            

            //Update each platform
            foreach (Sprite sprite in _platforms)
            {
                minLocation = PointFMath.Min(sprite.Location, minLocation);
                maxLocation = PointFMath.Max(sprite.Location, maxLocation);


                sprite.Velocity = new PointF(_direction.X * _speed, _direction.Y * _speed);


                sprite.Update(gameTime, elapsedTime);
            }

            //Set up the direction for the next frame
            switch (_movement)
            {
                case PlatformMovement.Left:
                case PlatformMovement.Right:
                    // If we have hit the edge of the screen we are moving towards
                    if ((minLocation.X < 0 && _movement == PlatformMovement.Left)
                        ||
                        (maxLocation.X + PlatformSprite.Width > _gameState.GameArea.Width && _movement == PlatformMovement.Right))
                    {

                        // Then we reverse direction
                        _movement = (_movement == PlatformMovement.Left) ? PlatformMovement.Right : PlatformMovement.Left;

                        if (_movement == PlatformMovement.Left)
                        {
                            _direction.X = -1;
                            _direction.Y = 0;
                        }
                        else
                        {
                            _direction.X = 1;
                            _direction.Y = 0;
                        }
                    }
                    break;
            }


        }

        public override void Draw(Graphics graphics)
        {
            // Render each platform
            foreach (Sprite sprite in _platforms)
            {
                sprite.Draw(graphics);
            }
        }

        public Sprite CheckCollisions(Sprite collider)
        {
            //Search for any platforms that collide with the passed in sprite
            foreach (Sprite sprite in _platforms)
            {
                if (Sprite.Collision(collider, sprite))
                {
                    return sprite;
                }
            }
            return null;

        }

        public bool CheckCollisionTop(Sprite collider)
        {
            //Search for any platforms that collide with the passed in sprite
            foreach (Sprite sprite in _platforms)
            {
                if (Sprite.CollisionTop(collider, sprite))
                {
                    return true;
                }
            }
            return false;
        }

        public bool CheckCollisionBottom(Sprite collider)
        {
            //Search for any platforms that collide with the passed in sprite
            foreach (Sprite sprite in _platforms)
            {
                if (Sprite.CollisionBottom(collider, sprite))
                {
                    return true;
                }
            }
            return false;
        }

        public bool CheckCollisionLeft(Sprite collider)
        {
            //Search for any platforms that collide with the passed in sprite
            foreach (Sprite sprite in _platforms)
            {
                if (Sprite.CollisionLeft(collider, sprite))
                {
                    return true;
                }
            }
            return false;
        }

        public bool CheckCollisionRight(Sprite collider)
        {
            //Search for any platforms that collide with the passed in sprite
            foreach (Sprite sprite in _platforms)
            {
                if (Sprite.CollisionRight(collider, sprite))
                {
                    return true;
                }
            }
            return false;
        }

        private enum PlatformMovement
        {
            Left,
            Right,
            Up,
            Down
        }
    }
}