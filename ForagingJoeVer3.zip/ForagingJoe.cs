﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace ForagingJoe
{
    public partial class ForagingJoe : Form
    {
        // This is the lowest code of the game.
        // The form is what initializes the game state as well as other very important variables.
        // I've placed a lot of comments throughout the application.
        // This is to help me learn more about the code that is based on the SpaceBlitz game.

        // initalize the main timer
        private Stopwatch _timer = new Stopwatch();
        // delta time variables
        private double _lastFrameTime;
        private long _frameCounter;
        // we set the gamestate here in the form
        private GameState _gameState;

        public ForagingJoe()
        {
            // Initialize form components
            InitializeComponent();
            // We set the style of the form controls through this. AllPaintingInWmPaint and OptimizedDoubleBuffer are meant to reduce flickering.
            // UserPaint has the control paint itself rather than the operating system. This makes it more efficient when drawing which is necessary for a game drawing many things at once.
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);
            // create a new game state based on the client size of the form. 
            _gameState = new GameState(ClientSize);

            // initalize game
            initialize();
        }

        private void initialize()
        {
            // run the Initialize method in the game state object
            _gameState.Initialize();
            
            // reset the last frame time
            _lastFrameTime = 0.0;
            // reset the main timer
            _timer.Reset();
            _timer.Start();
        }

        private void ForagingJoe_Paint(object sender, PaintEventArgs e)
        {
            // delta time variables
            // This allows the game to be updated based on the time elapsed rather than framerate
            // this means that no matter how fast the computer draws the frames, the game will be at the same speed

            // the game time is based on elapsed milliseconds for precision 
            double gameTime = _timer.ElapsedMilliseconds / 1000.0;
            // we get the elapsed time by getting the difference of the game time and the last frame update
            double elapsedTime = gameTime - _lastFrameTime;
            // The game has to loop to set the last updated frame time, so we place it after the delta time is set
            _lastFrameTime = gameTime;
            // increment the frame counter
            _frameCounter++;

            // Update the game as a whole
            _gameState.Update(gameTime, elapsedTime);

            // Draw all the things
            _gameState.Draw(e.Graphics);

            // force a redraw
            this.Invalidate();
        }

        private void ForagingJoe_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                // quit the game
                this.Close();
            }
            
            if (_gameState.State != States.Playing)
            {
                if (_gameState.State == States.GameOver)
                {
                    initialize();
                }
                _gameState.State = States.Playing;
                
            }
            Keyboard.KeyDown(e.KeyCode);
        }

        private void ForagingJoe_KeyUp(object sender, KeyEventArgs e)
        {
            Keyboard.KeyUp(e.KeyCode);
        }
    }
}
