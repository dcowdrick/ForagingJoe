﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing;

namespace ForagingJoe
{
    public class Player : Sprite
    {
        public const string _playerBitmap = @"graphics\Player.bmp";
        public double speed = 150;
        // gravity is set in gamestate
        private double _jumpForce = -200.0;
        private double _jumpForceRelease = -100.0;
        public bool IsGrounded;
        //private PlayerMovement _movement;

        public Player(GameState gameState, float x, float y)
            :base(gameState, x, y, _playerBitmap)
        {
        }

        public override void Update(double gameTime, double elapsedTime)
        {
            double velocity = 0.0;
            IsGrounded = Location.Y >= _gameState.GameArea.Height - Size.Height;
            //Set the velocity of the sprite based on which keys are pressed

            if (Keyboard.Left && !_gameState.platforms.CheckCollisionLeft(this))
            {
                //_movement = PlayerMovement.Left;
                velocity += -speed;
            }
            if (Keyboard.Right && !_gameState.platforms.CheckCollisionRight(this))
            {
                //_movement = PlayerMovement.Right;
                velocity += speed;
            }
            if (Keyboard.Left || Keyboard.Right)
            {
                Velocity.X = (float)velocity;
            }
            

            if (!Keyboard.Left && !Keyboard.Right)
            {
                Velocity.X = (float)velocity;
            }
            // Stops the player after the keys are released


            if (Keyboard.Space && IsGrounded)
            {
                // Give a vertical boost to the players velocity to start jump
                Velocity.Y = (float)_jumpForce;
            }

            if (!Keyboard.Space)
            {
                // If character is still ascending in the jump
                // Limit the speed of ascent
                if (Velocity.Y < (float)_jumpForceRelease)
                    Velocity.Y = (float)_jumpForceRelease;
            }

            Velocity.Y += (float)_gameState.gravity * (float)elapsedTime;

            // Allow vertical movement
            //if (Keyboard.Up)
            //{
            //    velocity += -_speed;
            //}
            //if (Keyboard.Down)
            //{
            //    velocity += _speed;
            //}
            //if (Keyboard.Up || Keyboard.Down)
            //{
            //    Velocity.Y = (float)velocity;
            //}
            //if (!Keyboard.Up && !Keyboard.Down)
            //{
            //    Velocity.Y = (float)velocity;
            //}


            //Perform any animation
            base.Update(gameTime, elapsedTime);

            //Limit the animation to the screen
            if (Location.X < 0) Location.X = 0;
            if (Location.X > _gameState.GameArea.Width - Size.Width) Location.X = _gameState.GameArea.Width - Size.Width;
            if (Location.Y < 0) Location.Y = 0;
            if (Location.Y > _gameState.GameArea.Height - Size.Height) Location.Y = _gameState.GameArea.Height - Size.Height;
        }

        // For player collisions against a platform...
        // we must check which direction the platform is in relative to the player
        // then we disallow the player from moving in that direction

        public Sprite CheckCollisions()
        {
            foreach (GameObject gameObject in _gameState.GameObjects)
            {
                if (gameObject is Enemy)
                {
                    Sprite enemyHit = ((Enemy)gameObject).CheckCollisions(this);
                    if (enemyHit != null)
                    {
                        return enemyHit;
                    }
                }
                else if (gameObject is Platform)
                {
                    Sprite platformHit = ((Platform)gameObject).CheckCollisions(this);
                    if (platformHit != null)
                    {
                        return platformHit;
                    }
                }
            }
            return null;
        }

        private enum PlayerMovement
        {
            Left,
            Right,
            Up,
            Down
        }
    }
}