﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace ForagingJoe
{
    static class PointFMath
    {
        public static PointF Min(PointF val1, PointF val2)
        {
            return new PointF(Math.Min(val1.X, val2.X), Math.Min(val1.Y, val2.Y));
        }

        public static PointF Max(PointF val1, PointF val2)
        {
            return new PointF(Math.Max(val1.X, val2.X), Math.Max(val1.Y, val2.Y));
        }

    }
}