﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace ForagingJoe
{
    public static class Keyboard
    {
        
        public static bool Left = false;
        public static bool Right = false;
        public static bool Up = false;
        public static bool Down = false;
        public static bool Space = false;


        public static void KeyDown(Keys keys)
        {
            if (keys == Keys.Left) Left = true;
            if (keys == Keys.Right) Right = true;
            if (keys == Keys.Up) Up = true;
            if (keys == Keys.Down) Down = true;
            if (keys == Keys.Space) Space = true;
        }

        public static void KeyUp(Keys keys)
        {
            if (keys == Keys.Left) Left = false;
            if (keys == Keys.Right) Right = false;
            if (keys == Keys.Up) Up = false;
            if (keys == Keys.Down) Down = false;
            if (keys == Keys.Space) Space = false;
        }
    }
}