﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class Platform
    {
        public PictureBox NewPlatform(string name, Size location, Point size, Image image, bool enabled, bool visible, Color color)
        {
            PictureBox platform = new PictureBox();
            platform = new PictureBox();
            platform.Name = name;
            platform.Location = new Point(location);
            platform.Size = new Size(size);
            platform.Image = image;
            platform.Enabled = enabled;
            platform.Visible = visible;
            platform.BackColor = color;

            return platform;
        }

    }
}
