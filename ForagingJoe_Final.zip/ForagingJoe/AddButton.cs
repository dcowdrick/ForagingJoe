﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class AddButton
    {
        public Button button;

        public void Add(string name, Size location, Point size, Color backcolor, FlatStyle style,
            string fontFamily, float fontSize, FontStyle fontStyle, Color forecolor, bool enabled, bool visible, string text, EventHandler handler)
        {
            this.button = new Button();
            this.button.Name = name;
            this.button.Location = new Point(location);
            this.button.Size = new Size(size);
            this.button.BackColor = backcolor;
            this.button.FlatStyle = style;
            this.button.Font = new Font(fontFamily, fontSize, fontStyle);
            this.button.ForeColor = forecolor;
            this.button.Enabled = enabled;
            this.button.Visible = visible;
            this.button.Text = text;
            this.button.Click += new EventHandler(handler);
            this.button.BringToFront();
        }

        void ButtonHandler(object sender, EventArgs e)
        {
            
        }
    }
}
