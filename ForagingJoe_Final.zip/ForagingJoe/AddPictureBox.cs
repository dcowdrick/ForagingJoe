﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class AddPictureBox
    {
        public PictureBox picturebox;

        public void Add(string name, Size location, Point size, Image image, bool enabled, bool visible, Color color)
        {
            this.picturebox = new PictureBox();
            this.picturebox.Name = name;
            this.picturebox.Location = new Point(location);
            this.picturebox.Size = new Size(size);
            this.picturebox.Image = image;
            this.picturebox.Enabled = enabled;
            this.picturebox.Visible = visible;
            this.picturebox.BackColor = color;
        }
    }
}
