﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class AddTextbox
    {
        public TextBox NewTextBox(string name, Size location, Point size, bool enabled, bool visible, string fontFamily, float fontSize, FontStyle fontStyle, Color foreColor, string labelText)
        {
            TextBox textbox = new TextBox();
            textbox = new TextBox();
            textbox.Name = name;
            textbox.Location = new Point(location);
            textbox.Size = new Size(size);
            textbox.Enabled = enabled;
            textbox.Visible = visible;
            //textbox.BackColor = backColor;
            textbox.Font = new Font(fontFamily, fontSize, fontStyle);
            textbox.ForeColor = foreColor;
            textbox.Text = labelText;

            return textbox;
        }

    }
}
