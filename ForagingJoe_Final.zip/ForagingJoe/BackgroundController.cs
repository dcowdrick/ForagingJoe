﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class BackgroundController
    {
        public PictureBox Background()
        {
            PictureBox background = new PictureBox();
            background.Name = "Background";
            background.Location = new Point(0, 0);
            background.Size = new Size(4500, 450);
            background.Image = ForagingJoe.Properties.Resources.repeating_clouds;
            background.Enabled = true;
            background.Visible = true;
            background.BackColor = Color.Transparent;

            return background;
        }
    }
}
