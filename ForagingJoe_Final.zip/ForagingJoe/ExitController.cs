﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class ExitController
    {
        public PictureBox NewExit(Size location)
        {
            PictureBox exit = new PictureBox();
            exit.Name = "Exit";
            exit.Location = new Point(location);
            exit.Size = new Size(114, 176);
            exit.Image = ForagingJoe.Properties.Resources.exit;
            exit.Enabled = true;
            exit.Visible = true;
            exit.BackColor = Color.Transparent;

            return exit;
        }
    }
}
