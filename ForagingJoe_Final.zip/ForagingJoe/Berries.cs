﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class Berries
    {
        public PictureBox NewBerries(string name, Size location, Point size, Image image, bool enabled, bool visible, Color backColor)
        {
            PictureBox berries = new PictureBox();
            berries = new PictureBox();
            berries.Name = name;
            berries.Location = new Point(location);
            berries.Size = new Size(size);
            berries.Image = image;
            berries.Enabled = enabled;
            berries.Visible = visible;
            berries.BackColor = backColor;

            return berries;
        }

    }
}
