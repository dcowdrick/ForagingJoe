﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class PlayerController
    {
        public PictureBox NewPlayer()
        {
            PictureBox player = new PictureBox();
            player.Name = "Player";
            player.Location = new Point(336, 185);
            player.Size = new Size(114, 176);
            player.Image = ForagingJoe.Properties.Resources.run0;
            player.Enabled = true;
            player.Visible = true;
            player.BackColor = Color.Transparent;
            
            return player;
        }

        public void MovePlayer(Timer timer)
        { 
        }
    }
}
