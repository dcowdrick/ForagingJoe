﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ForagingJoe
{
    public partial class Form1 : Form
    {
        int platformSpriteX = 50;
        int platformSpriteY = 50;

        int currentScore = 0;
        int currentLives = 3;

        int backgroundPositionX = 0;
        static int platform1PositionX = 0;
        static int platform2PositionX = platform1PositionX + 650;
        static int platform3PositionX = platform2PositionX + 650;
        static int platform4PositionX = platform3PositionX + 650;
        static int platform5PositionX = platform4PositionX + 650;
        static int platform6PositionX = platform5PositionX + 650;
        int berriesPositionX = 700;
        int berries2PositionX = 1000;
        int berries3PositionX = 1300;
        int berries4PositionX = 1700;
        int berries5PositionX = 2000;
        int berries6PositionX = 2300;
        int berries7PositionX = 2700;
        int berries8PositionX = 3000;
        int berries9PositionX = 3300;
        int berries10PositionX = 4000;
        int enemyPositionX = 758;
        int enemy2PositionX = 2000;
        int enemy3PositionX = 3000;
        int exitPositionX = 3600;

        int playerSprite;

        int enemySprite = 1;

        bool jumping = false;
        bool forward = false;
        bool backward = false;
        bool enemy1Trigger = false;
        bool enemy2Trigger = false;
        bool enemy3Trigger = false;
        bool falling = false;

        string playerName = "";

        PlayerController playerController = new PlayerController();
        BackgroundController backgroundController = new BackgroundController();
        Platform platform = new Platform();
        Enemy enemy = new Enemy();
        ExitController exitController = new ExitController();
        

        PictureBox player = new PictureBox();
        PictureBox background = new PictureBox();
        PictureBox[] platform1 = new PictureBox[11];
        PictureBox[] platform2 = new PictureBox[11];
        PictureBox[] platform3 = new PictureBox[11];
        PictureBox[] platform4 = new PictureBox[11];
        PictureBox[] platform5 = new PictureBox[11];
        PictureBox[] platform6 = new PictureBox[11];
        PictureBox exit = new PictureBox();

        PictureBox[] berries1 = new PictureBox[20];
        PictureBox[] enemies = new PictureBox[20];

        AddLabel addLabel = new AddLabel();
        AddTextbox addTextBox = new AddTextbox();

        Berries berries = new Berries();

        Label score = new Label();
        Label lives = new Label();
        Label scoreText = new Label();
        Label livesText = new Label();
        Label rankTitle = new Label();
        Label nameTitle = new Label();
        Label scoreTitle = new Label();
        Label highScores = new Label();
        //Label positionLabel = new Label();
        //Label playerPosition = new Label();
        //Label berryPosition = new Label();
        //Label berry2Position = new Label();

        TextBox name = new TextBox();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            runTimer.Enabled = false;
            AddBackground();
            AddPlayButton();
            AddQuitButton();
            AddLogo();

            //Create tempscores.txt if it doesn't exist
            if(!File.Exists("tempscores.csv"))
            {
                using (StreamWriter writetext = new StreamWriter("tempscores.csv", true))
                {
                    for(int i = 0; i < 10; i++)
                    {
                        writetext.WriteLine("-----,0");
                    }
                }
            }
        }

        void PlayButtonHandler(object sender, EventArgs e)
        {
            InitializeGame();
        }

        void QuitButtonHandler(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void RePlayButtonHandler(object sender, EventArgs e)
        {
            Application.Restart();
        }

        void OKButtonHandler(object sender, EventArgs e)
        {
            playerName = name.Text;

            //Write score to temporary file
            using (StreamWriter writetext = new StreamWriter("tempscores.csv", true))
            {
                writetext.WriteLine(playerName + "," + currentScore);
            }

            //Sort tempscores.csv
            var sorted = File.ReadLines("tempscores.csv")
                .Select(line => new
                {
                    SortKey = Int32.Parse(line.Split(',')[1]),
                    Line = line
                })
        .OrderByDescending(x => x.SortKey)
        .Select(x => x.Line);
            File.WriteAllLines("scores.csv", sorted);

            Controls.Clear();

            using (var reader = new StreamReader(@"scores.csv"))
            {
                List<string> names = new List<string>();
                List<string> scores = new List<string>();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');

                    names.Add(values[0]);
                    scores.Add(values[1]);
                }

                highScores = addLabel.NewLabel("highScores", new Size(377, 9), new Point(180, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "High Scores");
                Controls.Add(highScores);

                rankTitle = addLabel.NewLabel("rankTitle", new Size(230, 40), new Point(107, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "Rank");
                Controls.Add(rankTitle);

                nameTitle = addLabel.NewLabel("nameTitle", new Size(370, 40), new Point(107, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "Name");
                Controls.Add(nameTitle);

                scoreTitle = addLabel.NewLabel("nameTitle", new Size(607, 40), new Point(107, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "Score");
                Controls.Add(scoreTitle);

                AddReplayButton();
                AddQuitButton();

                Label[] rankLabel = new Label[10];
                Label[] nameLabel = new Label[10];
                Label[] scoreLabel = new Label[10];

                int rankX = 230;
                int rankY = 80;
                int nameX = 370;
                int nameY = 80;
                int scoreX = 607;
                int scoreY = 80;

                for (int i = 0; i < 5; i++)
                {
                    try
                    {
                        rankLabel[i] = new Label();
                        rankLabel[i].Name = "rank" + i;
                        rankLabel[i].Location = new Point(rankX, rankY);
                        rankLabel[i].Size = new Size(107, 31);
                        rankLabel[i].Enabled = true;
                        rankLabel[i].Visible = true;
                        rankLabel[i].BackColor = Color.Transparent;
                        rankLabel[i].Font = new Font("Microsoft Sans Serif", 20, FontStyle.Bold);
                        rankLabel[i].ForeColor = Color.Red;
                        rankLabel[i].Text =  i + 1 +":";
                        Controls.Add(rankLabel[i]);

                        nameLabel[i] = new Label();
                        nameLabel[i].Name = "name" + i;
                        nameLabel[i].Location = new Point(nameX, nameY);
                        nameLabel[i].Size = new Size(120, 31);
                        nameLabel[i].Enabled = true;
                        nameLabel[i].Visible = true;
                        nameLabel[i].BackColor = Color.Transparent;
                        nameLabel[i].Font = new Font("Microsoft Sans Serif", 20, FontStyle.Bold);
                        nameLabel[i].ForeColor = Color.Red;
                        nameLabel[i].Text = names[i];
                        Controls.Add(nameLabel[i]);

                        scoreLabel[i] = new Label();
                        scoreLabel[i].Name = "score" + i;
                        scoreLabel[i].Location = new Point(scoreX, scoreY);
                        scoreLabel[i].Size = new Size(107, 31);
                        scoreLabel[i].Enabled = true;
                        scoreLabel[i].Visible = true;
                        scoreLabel[i].BackColor = Color.Transparent;
                        scoreLabel[i].Font = new Font("Microsoft Sans Serif", 20, FontStyle.Bold);
                        scoreLabel[i].ForeColor = Color.Red;
                        scoreLabel[i].Text = scores[i];
                        Controls.Add(scoreLabel[i]);

                        rankY += 40;
                        nameY += 40;
                        scoreY += 40;
                    }
                    catch(IndexOutOfRangeException)
                    {
                        MessageBox.Show("OOPS!");
                    }
                }
            }
        }

        private void AddBackground()
        {
            Form1 form1 = new Form1();
            form1.BackgroundImage = ForagingJoe.Properties.Resources.clouds;
        }

        private void AddPlayButton()
        {
            AddButton addButton = new AddButton();
            addButton.Add("btnPlay", new Size(312, 308), new Point(100, 50), Color.DeepSkyBlue, FlatStyle.Flat,
                "Comic Sans MS", 20.25f, FontStyle.Bold, Color.Red, true, true, "Play", this.PlayButtonHandler);
            Controls.Add(addButton.button);
        }

        private void AddQuitButton()
        {
            AddButton addButton = new AddButton();
            addButton.Add("btnQuit", new Size(476, 308), new Point(100, 50), Color.DeepSkyBlue, FlatStyle.Flat,
                "Comic Sans MS", 20.25f, FontStyle.Bold, Color.Red, true, true, "Quit", this.QuitButtonHandler);
            Controls.Add(addButton.button);
        }

        private void AddLogo()
        {
            AddPictureBox addpictureBox = new AddPictureBox();
            addpictureBox.Add("Logo", new Size(225, 0), new Point(450, 450), ForagingJoe.Properties.Resources.logo, true, true, Color.Transparent);
            Controls.Add(addpictureBox.picturebox);
        }

        private void AddGameOver()
        {
            AddPictureBox addpictureBox = new AddPictureBox();
            addpictureBox.Add("Logo", new Size(225, 0), new Point(450, 450), ForagingJoe.Properties.Resources.gameover, true, true, Color.Transparent);
            Controls.Add(addpictureBox.picturebox);
        }

        private void AddOkButton()
        {
            AddButton addButton = new AddButton();
            addButton.Add("btnOK", new Size(400, 300), new Point(100, 50), Color.DeepSkyBlue, FlatStyle.Flat,
                "Comic Sans MS", 20.25f, FontStyle.Bold, Color.Red, true, true, "OK", this.OKButtonHandler);
            Controls.Add(addButton.button);
        }

        private void AddReplayButton()
        {
            AddButton addButton = new AddButton();
            addButton.Add("btnReplay", new Size(312, 308), new Point(100, 50), Color.DeepSkyBlue, FlatStyle.Flat,
                "Comic Sans MS", 20.25f, FontStyle.Bold, Color.Red, true, true, "Play", this.RePlayButtonHandler);
            Controls.Add(addButton.button);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Right && !jumping)
            {
                runTimer.Start();
                forward = true;
                backward = false;
            }

            if (e.KeyCode == Keys.Left && !jumping)
            {
                runTimer.Start();
                forward = false;
                backward = true;
            }

            if (e.KeyCode == Keys.Space)
            {
                player.Image = (Image)Properties.Resources.ResourceManager.GetObject("jump");
                
                jumpTimer.Start();
                runTimer.Stop();
                jumping = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Animate player sprite
            if (playerSprite >= 2)
            {
                playerSprite = 0;
            }
            else
            {
                playerSprite++;
            }

            player.Image = (Image)Properties.Resources.ResourceManager.GetObject("run" + playerSprite);
            
            if(forward)
            {
                MoveForward();
            }

            if(backward)
            {
                MoveBackward();
            }
            

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                runTimer.Stop();
                forward = false;
            }
            if (e.KeyCode == Keys.Left)
            {
                runTimer.Stop();
                backward = false;
            }

            if (e.KeyCode == Keys.Space)
            {
                
            }
                
        }

        private void jumpTimer_Tick(object sender, EventArgs e)
        {
           
                if(player.Location.Y >= 0 && jumping)
                {
                //player.Location = new Point(player.Location.X, (playerSpriteY - 10));
                    MoveForward();
                
                player.Location = new Point(player.Location.X, (player.Location.Y - 10));
                    if(player.Location.Y <= 0)
                    {
                        jumping = false;
                    }
                {

                }
                }
                else
                {
                    if(player.Location.Y <= 185 && !jumping)
                    {
                    MoveForward();
                    player.Location = new Point(player.Location.X, player.Location.Y + 10);
                        if(player.Location.Y >= 185)
                    {
                        player.Location = new Point(player.Location.X, 185);
                        player.Image = ForagingJoe.Properties.Resources.run0;
                        jumpTimer.Stop();
                    }
                    }
                }
        }

        private void enemyTimer_Tick(object sender, EventArgs e)
        {
            enemies[0].Location = new Point(enemyPositionX, 219);
            enemyPositionX = enemyPositionX - 10;
            
            enemies[1].Location = new Point(enemy2PositionX, 219);
            enemy2PositionX = enemy2PositionX - 10;

            enemies[2].Location = new Point(enemy3PositionX, 219);
            enemy3PositionX = enemy3PositionX - 10;

            if (enemySprite > 1)
            {
                enemySprite = 1;
            }
            else
            {
                enemySprite++;
            }

            enemies[0].Image = (Image)Properties.Resources.ResourceManager.GetObject("bear" + enemySprite);
            enemies[1].Image = (Image)Properties.Resources.ResourceManager.GetObject("bear" + enemySprite);
            enemies[2].Image = (Image)Properties.Resources.ResourceManager.GetObject("bear" + enemySprite);

            if (player.Location.X > enemies[0].Location.X & player.Location.Y == 185 & !enemy1Trigger)
            {
                if (player.Location.X - enemies[0].Location.X < 50)
                {
                    enemy1Trigger = true;
                    currentLives--;
                    lives.Text = currentLives.ToString();
                    enemyTimer.Enabled = false;
                    enemyTimer.Stop();
                    
                }
            }
            
            if (player.Location.X > enemies[1].Location.X & player.Location.Y == 185 & !enemy2Trigger)
            {
                if (player.Location.X - enemies[1].Location.X < 50)
                {
                    enemy2Trigger = true;
                    currentLives--;
                    lives.Text = currentLives.ToString();
                    enemyTimer.Enabled = false;
                    enemyTimer.Stop();
                }
            }

            if (player.Location.X > enemies[2].Location.X & player.Location.Y == 185 & !enemy3Trigger)
            {
                if (player.Location.X - enemies[2].Location.X < 50)
                {
                    enemy3Trigger = true;
                    currentLives--;
                    lives.Text = currentLives.ToString();
                    enemyTimer.Enabled = false;
                    enemyTimer.Stop();
                }

            }
        }

        private void InitializeGame()
        {
            
            Controls.Clear();

            
            //positionLabel.Location = new Point(100,100);
            //Controls.Add(positionLabel);

            //berryPosition.Location = new Point(100, 200);
            //Controls.Add(berryPosition);

            //berry2Position.Location = new Point(100, 300);
            //Controls.Add(berry2Position);

            //currentScore = 0;
            //currentLives = 3;
            enemy1Trigger = false;
            enemy2Trigger = false;
            enemy3Trigger = false;

            enemyTimer.Enabled = true;
            enemyTimer.Start();

            globalTimer.Enabled = true;
            globalTimer.Start();

           berries1[0] = berries.NewBerries("berries1", new Size(700, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[0]);

            berries1[1] = berries.NewBerries("berries2", new Size(1000, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[1]);

            berries1[2] = berries.NewBerries("berries3", new Size(1300, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[2]);

            berries1[3] = berries.NewBerries("berries4", new Size(1700, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[3]);

            berries1[4] = berries.NewBerries("berries5", new Size(2000, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[4]);

            berries1[5] = berries.NewBerries("berries6", new Size(2300, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[5]);

            berries1[6] = berries.NewBerries("berries7", new Size(2700, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[6]);

            berries1[7] = berries.NewBerries("berries8", new Size(3000, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[7]);

            berries1[8] = berries.NewBerries("berries9", new Size(3300, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[8]);

            berries1[9] = berries.NewBerries("berries10", new Size(3700, 311), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.berries, true, true, Color.Transparent);
            Controls.Add(berries1[9]);


            enemies[0] = enemy.NewEnemy("Enemy0", new Size(758, 219), new Point(114, 142),
                    ForagingJoe.Properties.Resources.bear1, true, true, Color.Transparent);
            Controls.Add(enemies[0]);

            enemies[1] = enemy.NewEnemy("Enemy1", new Size(2000, 219), new Point(114, 142),
                   ForagingJoe.Properties.Resources.bear1, true, true, Color.Transparent);
            Controls.Add(enemies[1]);

            enemies[2] = enemy.NewEnemy("Enemy2", new Size(3000, 219), new Point(114, 142),
                   ForagingJoe.Properties.Resources.bear1, true, true, Color.Transparent);
            Controls.Add(enemies[2]);

            exit = exitController.NewExit(new Size(3600, 185));
            Controls.Add(exit);

            int xPoint;
            xPoint = 0;
            for (int i = 0; i <= 10; i++)
            {

                platform1[i] = platform.NewPlatform("Platform1", new Size(xPoint, 361), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.platform, true, true, Color.Transparent);
                Controls.Add(platform1[i]);

                xPoint += 50;
            }

            xPoint += 100;

            for (int i = 0; i <= 10; i++)
            {
                platform2[i] = platform.NewPlatform("Platform2", new Size(xPoint, 361), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.platform, true, true, Color.Transparent);
                Controls.Add(platform2[i]);

                xPoint += 50;
            }

            xPoint += 100;

            for (int i = 0; i <= 10; i++)
            {
                platform3[i] = platform.NewPlatform("Platform3", new Size(xPoint, 361), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.platform, true, true, Color.Transparent);
                Controls.Add(platform3[i]);

                xPoint += 50;
            }

            xPoint += 100;

            for (int i = 0; i <= 10; i++)
            {
                platform4[i] = platform.NewPlatform("Platform4", new Size(xPoint, 361), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.platform, true, true, Color.Transparent);
                Controls.Add(platform4[i]);

                xPoint += 50;
            }

            xPoint += 100;

            for (int i = 0; i <= 10; i++)
            {
                platform5[i] = platform.NewPlatform("Platform5", new Size(xPoint, 361), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.platform, true, true, Color.Transparent);
                Controls.Add(platform5[i]);

                xPoint += 50;
            }

            xPoint += 100;

            for (int i = 0; i <= 10; i++)
            {
                platform6[i] = platform.NewPlatform("Platform6", new Size(xPoint, 361), new Point(platformSpriteX, platformSpriteY),
                    ForagingJoe.Properties.Resources.platform, true, true, Color.Transparent);
                Controls.Add(platform6[i]);

                xPoint += 50;
            }

            scoreText = addLabel.NewLabel("scoreText", new Size(12, 9), new Point(107, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "Score:");
            Controls.Add(scoreText);

            score = addLabel.NewLabel("score", new Size(125, 9), new Point(78, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "0");
            Controls.Add(score);

            livesText = addLabel.NewLabel("livesText", new Size(681, 9), new Point(92, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "Lives:");
            Controls.Add(livesText);

            lives = addLabel.NewLabel("lives", new Size(794, 9), new Point(78, 31), true, true, Color.Transparent,
                "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Red, "3");
            Controls.Add(lives);


            player = playerController.NewPlayer();
            Controls.Add(player);

            background = backgroundController.Background();
            Controls.Add(background);

            score.Text = currentScore.ToString();
            lives.Text = currentLives.ToString();

        }

        private void globalTimer_Tick(object sender, EventArgs e)
        {
            if(!enemyTimer.Enabled)
            {
                enemyTimer.Start();
            }

            for (int i = 0; i < 10; i++)
            {
                if (berries1[i].Location.X == 380 && berries1[i].Visible && player.Location.Y == 185)
                {
                    currentScore += 20;
                    score.Text = currentScore.ToString();
                    berries1[i].Visible = false;
                }
            }

            //if(enemies[0].Location.X <= 0)
            //{
            //    enemies[0].Location = new Point(3000,219);
            //    enemy1Trigger = false;
            //}

            if (currentLives == 0)
            {
                GameOver();
                globalTimer.Enabled = false;
                globalTimer.Stop();
            }

            if (player.Location.X > exit.Location.X)
            {
                globalTimer.Enabled = false;
                globalTimer.Stop();
                GameOver();
                MessageBox.Show("YOU WON!");
            }
        }

        private void GameOver()
        {
            Controls.Clear();

            AddOkButton();

            name = addTextBox.NewTextBox("name", new Size(350, 250), new Point(200, 38), true, true,
                 "Microsoft Sans Serif", 20, FontStyle.Bold, Color.Blue, "Enter name");
            Controls.Add(name);
            name.BringToFront();

            AddGameOver();
        }

        private void MoveForward()
        {
            //positionLabel.Text = background.Location.X.ToString();
            //berryPosition.Text = berries1[0].Location.X.ToString();
            //berry2Position.Text = berries1[1].Location.X.ToString();

            if (background.Location.X > -3620 && !falling)
            {
                background.Location = new Point(backgroundPositionX, 0);
                backgroundPositionX = backgroundPositionX - 10;

                platform1[0].Location = new Point(platform1PositionX, 361);
                platform1[1].Location = new Point(platform1PositionX + 50, 361);
                platform1[2].Location = new Point(platform1PositionX + 100, 361);
                platform1[3].Location = new Point(platform1PositionX + 150, 361);
                platform1[4].Location = new Point(platform1PositionX + 200, 361);
                platform1[5].Location = new Point(platform1PositionX + 250, 361);
                platform1[6].Location = new Point(platform1PositionX + 300, 361);
                platform1[7].Location = new Point(platform1PositionX + 350, 361);
                platform1[8].Location = new Point(platform1PositionX + 400, 361);
                platform1[9].Location = new Point(platform1PositionX + 450, 361);
                platform1[10].Location = new Point(platform1PositionX + 500, 361);

                platform2[0].Location = new Point(platform2PositionX, 361);
                platform2[1].Location = new Point(platform2PositionX + 50, 361);
                platform2[2].Location = new Point(platform2PositionX + 100, 361);
                platform2[3].Location = new Point(platform2PositionX + 150, 361);
                platform2[4].Location = new Point(platform2PositionX + 200, 361);
                platform2[5].Location = new Point(platform2PositionX + 250, 361);
                platform2[6].Location = new Point(platform2PositionX + 300, 361);
                platform2[7].Location = new Point(platform2PositionX + 350, 361);
                platform2[8].Location = new Point(platform2PositionX + 400, 361);
                platform2[9].Location = new Point(platform2PositionX + 450, 361);
                platform2[10].Location = new Point(platform2PositionX + 500, 361);

                platform3[0].Location = new Point(platform3PositionX, 361);
                platform3[1].Location = new Point(platform3PositionX + 50, 361);
                platform3[2].Location = new Point(platform3PositionX + 100, 361);
                platform3[3].Location = new Point(platform3PositionX + 150, 361);
                platform3[4].Location = new Point(platform3PositionX + 200, 361);
                platform3[5].Location = new Point(platform3PositionX + 250, 361);
                platform3[6].Location = new Point(platform3PositionX + 300, 361);
                platform3[7].Location = new Point(platform3PositionX + 350, 361);
                platform3[8].Location = new Point(platform3PositionX + 400, 361);
                platform3[9].Location = new Point(platform3PositionX + 450, 361);
                platform3[10].Location = new Point(platform3PositionX + 500, 361);

                platform4[0].Location = new Point(platform4PositionX, 361);
                platform4[1].Location = new Point(platform4PositionX + 50, 361);
                platform4[2].Location = new Point(platform4PositionX + 100, 361);
                platform4[3].Location = new Point(platform4PositionX + 150, 361);
                platform4[4].Location = new Point(platform4PositionX + 200, 361);
                platform4[5].Location = new Point(platform4PositionX + 250, 361);
                platform4[6].Location = new Point(platform4PositionX + 300, 361);
                platform4[7].Location = new Point(platform4PositionX + 350, 361);
                platform4[8].Location = new Point(platform4PositionX + 400, 361);
                platform4[9].Location = new Point(platform4PositionX + 450, 361);
                platform4[10].Location = new Point(platform4PositionX + 500, 361);

                platform5[0].Location = new Point(platform5PositionX, 361);
                platform5[1].Location = new Point(platform5PositionX + 50, 361);
                platform5[2].Location = new Point(platform5PositionX + 100, 361);
                platform5[3].Location = new Point(platform5PositionX + 150, 361);
                platform5[4].Location = new Point(platform5PositionX + 200, 361);
                platform5[5].Location = new Point(platform5PositionX + 250, 361);
                platform5[6].Location = new Point(platform5PositionX + 300, 361);
                platform5[7].Location = new Point(platform5PositionX + 350, 361);
                platform5[8].Location = new Point(platform5PositionX + 400, 361);
                platform5[9].Location = new Point(platform5PositionX + 450, 361);
                platform5[10].Location = new Point(platform5PositionX + 500, 361);

                platform6[0].Location = new Point(platform6PositionX, 361);
                platform6[1].Location = new Point(platform6PositionX + 50, 361);
                platform6[2].Location = new Point(platform6PositionX + 100, 361);
                platform6[3].Location = new Point(platform6PositionX + 150, 361);
                platform6[4].Location = new Point(platform6PositionX + 200, 361);
                platform6[5].Location = new Point(platform6PositionX + 250, 361);
                platform6[6].Location = new Point(platform6PositionX + 300, 361);
                platform6[7].Location = new Point(platform6PositionX + 350, 361);
                platform6[8].Location = new Point(platform6PositionX + 400, 361);
                platform6[9].Location = new Point(platform6PositionX + 450, 361);
                platform6[10].Location = new Point(platform6PositionX + 500, 361);

                berries1[0].Location = new Point(berriesPositionX + 50, 311);
                berries1[1].Location = new Point(berries2PositionX + 50, 311);
                berries1[2].Location = new Point(berries3PositionX + 50, 311);
                berries1[3].Location = new Point(berries4PositionX + 50, 311);
                berries1[4].Location = new Point(berries5PositionX + 50, 311);
                berries1[5].Location = new Point(berries6PositionX + 50, 311);
                berries1[6].Location = new Point(berries7PositionX + 50, 311);
                berries1[7].Location = new Point(berries8PositionX + 50, 311);
                berries1[8].Location = new Point(berries9PositionX + 50, 311);
                berries1[9].Location = new Point(berries10PositionX + 50, 311);

                exit.Location = new Point(exitPositionX + 50, 185);

                platform1PositionX = platform1PositionX - 10;
                platform2PositionX = platform2PositionX - 10;
                platform3PositionX = platform3PositionX - 10;
                platform4PositionX = platform4PositionX - 10;
                platform5PositionX = platform5PositionX - 10;
                platform6PositionX = platform6PositionX - 10;

                berriesPositionX = berriesPositionX - 10;
                berries2PositionX = berries2PositionX - 10;
                berries3PositionX = berries3PositionX - 10;
                berries4PositionX = berries4PositionX - 10;
                berries5PositionX = berries5PositionX - 10;
                berries6PositionX = berries6PositionX - 10;
                berries7PositionX = berries7PositionX - 10;
                berries8PositionX = berries8PositionX - 10;
                berries9PositionX = berries9PositionX - 10;
                berries10PositionX = berries10PositionX - 10;
                exitPositionX = exitPositionX - 10;

                //Defines where the player can fall
                if ((background.Location.X == -210 || background.Location.X == -840 || background.Location.X == -1520 ||
                    background.Location.X == -2140 || background.Location.X == -2800) && player.Location.Y >= 185)
                {
                    falling = true;
                    currentLives--;
                    lives.Text = currentLives.ToString();
                    fallTimer.Enabled = true;
                    fallTimer.Start();
                }
            }
           
        }

        private void MoveBackward()
        {
            //positionLabel.Text = background.Location.X.ToString();

            if (background.Location.X < 0 && !falling)
            {
                background.Location = new Point(backgroundPositionX, 0);
                backgroundPositionX = backgroundPositionX + 10;

                platform1[0].Location = new Point(platform1PositionX, 361);
                platform1[1].Location = new Point(platform1PositionX + 50, 361);
                platform1[2].Location = new Point(platform1PositionX + 100, 361);
                platform1[3].Location = new Point(platform1PositionX + 150, 361);
                platform1[4].Location = new Point(platform1PositionX + 200, 361);
                platform1[5].Location = new Point(platform1PositionX + 250, 361);
                platform1[6].Location = new Point(platform1PositionX + 300, 361);
                platform1[7].Location = new Point(platform1PositionX + 350, 361);
                platform1[8].Location = new Point(platform1PositionX + 400, 361);
                platform1[9].Location = new Point(platform1PositionX + 450, 361);
                platform1[10].Location = new Point(platform1PositionX + 500, 361);

                platform2[0].Location = new Point(platform2PositionX, 361);
                platform2[1].Location = new Point(platform2PositionX + 50, 361);
                platform2[2].Location = new Point(platform2PositionX + 100, 361);
                platform2[3].Location = new Point(platform2PositionX + 150, 361);
                platform2[4].Location = new Point(platform2PositionX + 200, 361);
                platform2[5].Location = new Point(platform2PositionX + 250, 361);
                platform2[6].Location = new Point(platform2PositionX + 300, 361);
                platform2[7].Location = new Point(platform2PositionX + 350, 361);
                platform2[8].Location = new Point(platform2PositionX + 400, 361);
                platform2[9].Location = new Point(platform2PositionX + 450, 361);
                platform2[10].Location = new Point(platform2PositionX + 500, 361);

                platform3[0].Location = new Point(platform3PositionX, 361);
                platform3[1].Location = new Point(platform3PositionX + 50, 361);
                platform3[2].Location = new Point(platform3PositionX + 100, 361);
                platform3[3].Location = new Point(platform3PositionX + 150, 361);
                platform3[4].Location = new Point(platform3PositionX + 200, 361);
                platform3[5].Location = new Point(platform3PositionX + 250, 361);
                platform3[6].Location = new Point(platform3PositionX + 300, 361);
                platform3[7].Location = new Point(platform3PositionX + 350, 361);
                platform3[8].Location = new Point(platform3PositionX + 400, 361);
                platform3[9].Location = new Point(platform3PositionX + 450, 361);
                platform3[10].Location = new Point(platform3PositionX + 500, 361);

                platform4[0].Location = new Point(platform4PositionX, 361);
                platform4[1].Location = new Point(platform4PositionX + 50, 361);
                platform4[2].Location = new Point(platform4PositionX + 100, 361);
                platform4[3].Location = new Point(platform4PositionX + 150, 361);
                platform4[4].Location = new Point(platform4PositionX + 200, 361);
                platform4[5].Location = new Point(platform4PositionX + 250, 361);
                platform4[6].Location = new Point(platform4PositionX + 300, 361);
                platform4[7].Location = new Point(platform4PositionX + 350, 361);
                platform4[8].Location = new Point(platform4PositionX + 400, 361);
                platform4[9].Location = new Point(platform4PositionX + 450, 361);
                platform4[10].Location = new Point(platform4PositionX + 500, 361);

                platform5[0].Location = new Point(platform5PositionX, 361);
                platform5[1].Location = new Point(platform5PositionX + 50, 361);
                platform5[2].Location = new Point(platform5PositionX + 100, 361);
                platform5[3].Location = new Point(platform5PositionX + 150, 361);
                platform5[4].Location = new Point(platform5PositionX + 200, 361);
                platform5[5].Location = new Point(platform5PositionX + 250, 361);
                platform5[6].Location = new Point(platform5PositionX + 300, 361);
                platform5[7].Location = new Point(platform5PositionX + 350, 361);
                platform5[8].Location = new Point(platform5PositionX + 400, 361);
                platform5[9].Location = new Point(platform5PositionX + 450, 361);
                platform5[10].Location = new Point(platform5PositionX + 500, 361);

                platform6[0].Location = new Point(platform6PositionX, 361);
                platform6[1].Location = new Point(platform6PositionX + 50, 361);
                platform6[2].Location = new Point(platform6PositionX + 100, 361);
                platform6[3].Location = new Point(platform6PositionX + 150, 361);
                platform6[4].Location = new Point(platform6PositionX + 200, 361);
                platform6[5].Location = new Point(platform6PositionX + 250, 361);
                platform6[6].Location = new Point(platform6PositionX + 300, 361);
                platform6[7].Location = new Point(platform6PositionX + 350, 361);
                platform6[8].Location = new Point(platform6PositionX + 400, 361);
                platform6[9].Location = new Point(platform6PositionX + 450, 361);
                platform6[10].Location = new Point(platform6PositionX + 500, 361);

                berries1[0].Location = new Point(berriesPositionX + 50, 311);
                berries1[0].Location = new Point(berriesPositionX + 50, 311);
                berries1[1].Location = new Point(berries2PositionX + 50, 311);
                berries1[2].Location = new Point(berries3PositionX + 50, 311);
                berries1[3].Location = new Point(berries4PositionX + 50, 311);
                berries1[4].Location = new Point(berries5PositionX + 50, 311);
                berries1[5].Location = new Point(berries6PositionX + 50, 311);
                berries1[6].Location = new Point(berries7PositionX + 50, 311);
                berries1[7].Location = new Point(berries8PositionX + 50, 311);
                berries1[8].Location = new Point(berries9PositionX + 50, 311);
                berries1[9].Location = new Point(berries10PositionX + 50, 311);
                exit.Location = new Point(exitPositionX + 50, 185);

                platform1PositionX = platform1PositionX + 10;
                platform2PositionX = platform2PositionX + 10;
                platform3PositionX = platform3PositionX + 10;
                platform4PositionX = platform4PositionX + 10;
                platform5PositionX = platform5PositionX + 10;
                platform6PositionX = platform6PositionX + 10;

                berriesPositionX = berriesPositionX + 10;
                berries2PositionX = berries2PositionX + 10;
                berries3PositionX = berries3PositionX + 10;
                berries4PositionX = berries4PositionX + 10;
                berries5PositionX = berries5PositionX + 10;
                berries6PositionX = berries6PositionX + 10;
                berries7PositionX = berries7PositionX + 10;
                berries8PositionX = berries8PositionX + 10;
                berries9PositionX = berries9PositionX + 10;
                berries10PositionX = berries10PositionX + 10;

                exitPositionX = exitPositionX + 10;

                //Defines where the player can fall
                if ((background.Location.X == -210 || background.Location.X == -840 || background.Location.X == -1520 ||
                    background.Location.X == -2140 || background.Location.X == -2800) && player.Location.Y >= 185)
                {
                    falling = true;
                    currentLives--;
                    lives.Text = currentLives.ToString();
                    fallTimer.Enabled = true;
                    fallTimer.Start();
                }
            }

        }

        private void fallTimer_Tick(object sender, EventArgs e)
        {
            player.Location = new Point(player.Location.X, (player.Location.Y + 10));
            if (player.Location.Y > 600)
            {
                falling = false;
                MoveBackward();
                MoveBackward();
                MoveBackward();
                MoveBackward();
                MoveBackward();
                MoveBackward();
                MoveBackward();
                MoveBackward();
                MoveBackward();
                MoveBackward();
                player.Location = new Point(336, 185);
                fallTimer.Enabled = false;
                fallTimer.Stop();
            }
        }
    }
}
