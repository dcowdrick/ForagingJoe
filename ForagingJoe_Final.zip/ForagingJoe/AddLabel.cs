﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class AddLabel
    {
        public Label NewLabel(string name, Size location, Point size, bool enabled, bool visible, Color backColor, string fontFamily, float fontSize, FontStyle fontStyle, Color foreColor, string labelText)
        {
            Label label = new Label();
            label = new Label();
            label.Name = name;
            label.Location = new Point(location);
            label.Size = new Size(size);
            label.Enabled = enabled;
            label.Visible = visible;
            label.BackColor = backColor;
            label.Font = new Font(fontFamily, fontSize, fontStyle);
            label.ForeColor = foreColor;
            label.Text = labelText;

            return label;
        }

    }
}
