﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class Enemy
    {
        public PictureBox NewEnemy(string name, Size location, Point size, Image image, bool enabled, bool visible, Color backColor)
        {
            PictureBox enemy = new PictureBox();
            enemy = new PictureBox();
            enemy.Name = name;
            enemy.Location = new Point(location);
            enemy.Size = new Size(size);
            enemy.Image = image;
            enemy.Enabled = enabled;
            enemy.Visible = visible;
            enemy.BackColor = backColor;

            return enemy;
        }

    }
}
