﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoe
{
    class PlatformController
    {
        public PictureBox NewPlatform(Size location)
        {
            PictureBox platform = new PictureBox();
            platform.Name = "Platform";
            platform.Location = new Point(location);
            platform.Size = new Size(50, 50);
            platform.Image = ForagingJoe.Properties.Resources.platform;
            platform.Enabled = true;
            platform.Visible = true;
            platform.BackColor = Color.Transparent;

            return platform;
        }

        public void MovePlayer(Timer timer)
        {
        }
    }
}
