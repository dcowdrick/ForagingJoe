﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace ForagingJoe
{
    public static class Keyboard
    {
        // Joe can only move left or right
        public static bool Left = false;
        public static bool Right = false;


        public static void KeyDown(Keys keys)
        {
            if (keys == Keys.Left) Left = true;
            if (keys == Keys.Right) Right = true;
        }

        public static void KeyUp(Keys keys)
        {
            if (keys == Keys.Left) Left = false;
            if (keys == Keys.Right) Right = false;
        }
    }
}