﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace ForagingJoe
{
    public partial class ForagingJoe : Form
    {
        private StopWatch _timer = new StopWatch();
        private double _lastTime;
        private long _frameCounter;
        private GameState _gameState;

        public ForagingJoe()
        {
            InitializeComponent();
            SetStyle(ControlStyles.AllPaintInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, true);

            _gameState = new GameState;

            initialize();
        }

        private void initialize()
        {
            _gameState.Initialize();

            _lastTime = 0.0;
            _timer.Reset();
            _timer.Start();
        }

        private void ForagingJoe_Paint(object sender, PaintEventArgs e)
        {
            // This allows the game to be updated based on the time elapsed rather than purely framerate
            double gameTime = _timer.ElapsedMilliseconds / 1000.0;
            double elapsedTime = gameTime - _lastTime;
            _lastTime = gameTime;
            _frameCounter++;

            // Update the game as a whole
            _gameState.Update(gameTime, elapsedTime);

            // Draw all the things
            _gameState.Draw(e.Graphics);

            // Go onto the next Paint
            this.Invalidate();
        }

        private void ForagingJoe_KeyDown(object sender, KeyEventArgs e)
        {
            if (_gameState.State != States.Playing)
            {
                if (_gameState.State == AccessibleStates.GameOver)
                {
                    initialize();
                }

                _gameState.State = States.Playing;
            }
        }

        private void ForagingJoe_KeyUp(object sender, KeyEventArgs e)
        {
            Keyboard.KeyUp(e.KeyCode);
        }
    }
}
