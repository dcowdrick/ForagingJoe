﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;


namespace ForagingJoe
{
    public class Sprite : GameObject
    {
        public PointF Velocity;
        public PointF Location;
        public SizeF Size;
        public int CurrentFrame;

        protected List<Bitmap> _frames = new List<Bitmap>();
        protected GameState _gameState;

        public Sprite(GameState gameState, float x, float y, string filename)
        {
            //Load the bitmap
            _frames.Add(new Bitmap(filename));

            //Set the location and use the height and width from the 1st frame
            initialize(gameState, x, y, _frames[0].Width, _frames[0].Height);

        }

        public Sprite(GameState gameState, float x, float y, string filename1, string filename2)
        {
            //Load the 2 animation frames
            _frames.Add(new Bitmap(filename1));
            _frames.Add(new Bitmap(filename2));

            initialize(gameState, x, y, _frames[0].Width, _frames[0].Height);
        }

        private void initialize(GameState gameState, float x, float y, float width, float height)
        {
            _gameState = gameState;
            Location.X = x;
            Location.Y = y;
            Size.Width = width;
            Size.Height = height;
            CurrentFrame = 0;
        }

        public override void Update(double gameTime, double elapsedTime)
        {
            //Move the sprite
            Location.X += Velocity.X * (float)elapsedTime;
            Location.Y += Velocity.Y * (float)elapsedTime;

        }

        public override void Draw(Graphics graphics)
        {
            //Draw the correct frame at the current point
            graphics.DrawImage(_frames[CurrentFrame], Location.X, Location.Y, Size.Width, Size.Height);
        }

        public static bool Collision(Sprite sprite1, Sprite sprite2)
        {
            //See if the sprite rectangles overlap
            // Give this a second look to understand it

            return !(sprite1.Location.X > sprite2.Location.X + sprite2.Size.Width
                || sprite1.Location.X + sprite1.Size.Width < sprite2.Location.X
                || sprite1.Location.X + sprite1.Size.Width < sprite2.Location.X
                || sprite1.Location.Y > sprite2.Location.Y + sprite2.Size.Height
                || sprite1.Location.Y + sprite1.Size.Height < sprite2.Location.Y);
        }
    }
}