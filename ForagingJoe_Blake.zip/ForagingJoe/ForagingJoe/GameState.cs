﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Media;

namespace ForagingJoe
{
    public class GameState
    {
        // The main game state.
        
        private const int _initialLives = 3;

        public int Score;
        public int Lives;
        public States State = States.Starting;
        public SizeF GameArea;
        public List<GameObject> GameObjects = new;
        private Player _player;

        //example of sound, change later

        //private SoundPlayer _dead = new SoundPlayer(@"sounds\dead.wav");

        private Font _font = new Font("Arial", 24);
        private Brush _brush = new SolidBrush(Color.White);
        private static Random _random = new Random();

        public GameState(SizeF gameArea)
        {
            GameArea = gameArea;

            // sounds have to be loaded
            //_dead.Load();
        }

        public void Draw(Graphics graphics)
        {
            foreach (GameObject gameObject in GameObjects)
            {
                gameObject.Draw(graphics);
            }

            if (State != State.Playing)
            {
                graphics.DrawString("Press any Key to play");
            }

            if (State == State.GameOver)
            {
                graphics.DrawString("GAME OVER", _font, _brush, 300, 260);
            }
        }

        public void Update(double gameTime, double elapsedTime)
        {
            //Updates all the game stuff
            if (State == States.Playing)
            {
                //Create or destroy any transient objects


                foreach (GameObject gameObject in GameObjects)
                {
                    gameObject.Update(gameTime, elapsedTime);
                }

                //Check for any collisions

                
            }
        }

        // put collision functions here







        public void Initialize()
        {
            //Create all of the objects
            GameObjects.Clear();

            _player = new Player(this, GameArea.Width / 2 - 20, GameArea.Height - 46);
            GameObjects.Add(_player);

            // Lives sprite
            GameObjects.Add(new Sprite(this, 0, 0, @"graphics\insertGraphicHere.bmp"));

            //Reset the game state
            Score = 0;
            Lives = _initialLives;
            //any other variables that need to be reset, place here



        }
    }



    public enum States
    {
        Starting,
        Playing,
        GameOver,
    }
}