﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoeFormAI
{
    public partial class Form1 : Form
    {
        // code from https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.picturebox.image?view=netframework-4.7.2

        // statements
        bool reverseDirection = false;
        bool gameOver = false;
        bool isJumping = false;
        bool isFalling = false;
        int playerOriginalY = 0;
        int playerJumpToY = 0;
        const int jumpHeight = 75;

        public Form1()
        {
            InitializeComponent();
            KeyDown += new KeyEventHandler(Form1_KeyDown);
            InitializeEnemyTimer();
            InitializeJumpTimer();
        }
        

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (!gameOver)
            {
                // code from https://social.msdn.microsoft.com/Forums/vstudio/en-US/767a9ba6-e8d4-4112-bf2a-edadfaf75e70/c-moving-an-image?forum=csharpgeneral

                // Get coordinates of objects
                int playerX = player.Location.X;
                int playerY = player.Location.Y;
                int enemyX = enemy.Location.X;
                int enemyY = enemy.Location.Y;
                int backgroundX = background.Location.X;
                int backgroundY = background.Location.Y;

                // Move the background and enemy instead of player
                // I might replace these with something else that doesn't allow a key press delay
                if (e.KeyCode == Keys.Right) { enemyX -= 5; backgroundX -= 5; }
                else if (e.KeyCode == Keys.Left) { enemyX += 5; backgroundX += 5; }
                //else if (e.KeyCode == Keys.Up) y -= 5;
                //else if (e.KeyCode == Keys.Down) y += 5;
                else if (e.KeyCode == Keys.Space)
                {
                    if (!isJumping && !isFalling)
                    {
                        playerOriginalY = playerY;
                        playerJumpToY = (playerY - jumpHeight);
                        isJumping = true;
                    }
                }

                //player.Location = new Point(x, y);
                enemy.Location = new Point(enemyX, enemyY);
                //player.Location = new Point(playerX, playerY);

                // reset background if it reaches a certain location
                 
                if (backgroundX > -300)
                {
                    background.Location = new Point(backgroundX, backgroundY);
                }
                else
                {
                    background.Location = new Point(0, 0);
                }
                // Start at the other end the screen if enemy goes outside the left side of the box

                if (enemyX < -5)
                {
                    enemy.Location = new Point(600, 272);
                }
            }
        }

        private void InitializeEnemyTimer()
        {
            enemyTimer.Interval = 100;
            enemyTimer.Tick += new EventHandler(EnemyTimer_Tick);

            // Enable timer.  
            enemyTimer.Enabled = true;
        }

        private void InitializeJumpTimer()
        {
            jumpTimer.Interval = 50;
            jumpTimer.Tick += new EventHandler(JumpT_Tick);

            // Enable timer.  
            jumpTimer.Enabled = true;
        }

        private void EnemyTimer_Tick(object Sender, EventArgs e)
        {
            if (!gameOver)
            {
                var playerPosX = player.Location.X;
                var playerPosY = player.Location.Y;
                var enemyPosX = enemy.Location.X;
                var enemyPosY = enemy.Location.Y;
                var distanceToPlayer = ((playerPosX - enemyPosX) * (playerPosX - enemyPosX) + (playerPosY - enemyPosY) * (playerPosY - enemyPosY));
                
                // Check distance to player
                // Show player lost
                if (distanceToPlayer <= 400 && !gameOver)
                {
                    // code from https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.messagebox?view=netframework-4.7.2
                    gameOver = true;
                    string message = "You died!";
                    string caption = "Game Over!";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult result;

                    // Displays the MessageBox.

                    result = MessageBox.Show(message, caption, buttons);

                    if (result == System.Windows.Forms.DialogResult.OK)
                    {

                        // Closes the parent form.

                        this.Close();

                    }
                }

                if (!reverseDirection)
                {
                    enemy.Left -= 5;
                }
                else if (reverseDirection)
                {
                    enemy.Left += 5;
                }

                // Reverse the direction of the enemy if they reach either end of the screen
                //if (!reverseDirection && enemy.Left <= 5)
                //{
                //    reverseDirection = true;
                //}
                //else if (reverseDirection && enemy.Left >= 480)
                //{
                //    reverseDirection = false;
                //}
            }
        }

        private void JumpT_Tick(object Sender, EventArgs e)
        {
            var playerX = player.Location.X;
            var playerY = player.Location.Y;
            if (!gameOver && (isJumping || isFalling))
            {
                if (!isFalling && playerY > playerJumpToY)
                {
                    playerY -= 5;
                }
                else if (playerY != playerOriginalY)
                {
                    isFalling = true;
                    playerY += 5;
                }
                else
                {
                    isJumping = false;
                    isFalling = false;
                }
                player.Location = new Point(playerX, playerY);
            }
        }
    }
}
