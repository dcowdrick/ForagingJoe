﻿//PictureBox pictureBox1 = new PictureBox();
//private Bitmap MyImage;

// Display an image

//public void ShowMyImage(String fileToDisplay, int xSize, int ySize)
//{
//    // Sets up an image object to be displayed
//    if (MyImage != null)
//    {
//        MyImage.Dispose();
//    }

//    // Stretches the image to fit the pictureBox.
//    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
//    MyImage = new Bitmap(fileToDisplay);
//    pictureBox1.ClientSize = new Size(xSize, ySize);
//    pictureBox1.Image = (Image)MyImage;



//// Test movement using psuedo positional values
///
//Random RandomNumber = new Random();
//int playerRandomPOS = RandomNumber.Next(0, 40);
//int enemyRandomPOS = RandomNumber.Next(0, 40);
//int playerEnemyDiff = 0;
//do
//{
//    //playerRandomPOS = RandomNumber.Next(0, 40);
//    //enemyRandomPOS = RandomNumber.Next(0, 40);
//    playerEnemyDiff = playerRandomPOS - enemyRandomPOS;
//    if (playerEnemyDiff < 0)
//    {
//        playerEnemyDiff *= 1;
//    }

//    Console.WriteLine("Current Player Position: {0}", playerRandomPOS);
//    Console.WriteLine("Current Enemy Position: {0}", enemyRandomPOS);
//}

//while (enemyRandomPOS != playerRandomPOS);

//Console.WriteLine("Enemy has reached Player");

//Creates a picture box with a flag of red and white stripes

//PictureBox pictureBox1 = new PictureBox();
//public void CreateBitmapAtRuntime()
//{
//    pictureBox1.Size = new Size(210, 110);
//    this.Controls.Add(pictureBox1);

//    Bitmap flag = new Bitmap(200, 100);
//    Graphics flagGraphics = Graphics.FromImage(flag);
//    int red = 0;
//    int white = 11;
//    while (white <= 100)
//    {
//        flagGraphics.FillRectangle(Brushes.Red, 0, red, 200, 10);
//        flagGraphics.FillRectangle(Brushes.White, 0, white, 200, 10);
//        red += 20;
//        white += 20;
//    }
//    pictureBox1.Image = flag;

//}




//private void TranslateImageTopToX(PictureBox actor)
//{
//    int imgWidth = actor.Image.Width;
//    int imgHeight = actor.Image.Height;
//    int boxWidth = actor.Size.Width;
//    int boxHeight = actor.Size.Height;

//    //This variable will hold the result
//    float X = e.X;
//    float Y = e.Y;
//    //Comparing the aspect ratio of both the control and the image itself.
//    if (imgWidth / imgHeight > boxWidth / boxHeight)
//    {
//        //If true, that means that the image is stretched through the width of the control.
//        //'In other words: the image is limited by the width.

//        //The scale of the image in the Picture Box.
//        float scale = boxWidth / imgWidth;

//        //Since the image is in the middle, this code is used to determinate the empty space in the height
//        //'by getting the difference between the box height and the image actual displayed height and dividing it by 2.
//        float blankPart = (boxHeight - scale * imgHeight) / 2;

//        Y -= blankPart;

//        //Scaling the results.
//        X /= scale;
//        Y /= scale;
//    }
//    else
//    {
//        //If true, that means that the image is stretched through the height of the control.
//        //'In other words: the image is limited by the height.

//        //The scale of the image in the Picture Box.
//        float scale = boxHeight / imgHeight;

//        //Since the image is in the middle, this code is used to determinate the empty space in the width
//        //'by getting the difference between the box width and the image actual displayed width and dividing it by 2.
//        float blankPart = (boxWidth - scale * imgWidth) / 2;
//        X -= blankPart;

//        //Scaling the results.
//        X /= scale;
//        Y /= scale;
//    }
//}