﻿namespace ForagingJoeFormAI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.enemyTimer = new System.Windows.Forms.Timer(this.components);
            this.background = new System.Windows.Forms.PictureBox();
            this.player = new System.Windows.Forms.PictureBox();
            this.enemy = new System.Windows.Forms.PictureBox();
            this.jumpTimer = new System.Windows.Forms.Timer(this.components);
            this.goodie = new System.Windows.Forms.PictureBox();
            this.DisplayScore = new System.Windows.Forms.Label();
            this.ScoreCollisionTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.background)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodie)).BeginInit();
            this.SuspendLayout();
            // 
            // enemyTimer
            // 
            this.enemyTimer.Enabled = true;
            // 
            // background
            // 
            this.background.ErrorImage = null;
            this.background.Image = ((System.Drawing.Image)(resources.GetObject("background.Image")));
            this.background.Location = new System.Drawing.Point(0, 0);
            this.background.Name = "background";
            this.background.Size = new System.Drawing.Size(1280, 450);
            this.background.TabIndex = 2;
            this.background.TabStop = false;
            // 
            // player
            // 
            this.player.Image = ((System.Drawing.Image)(resources.GetObject("player.Image")));
            this.player.Location = new System.Drawing.Point(128, 418);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(32, 32);
            this.player.TabIndex = 0;
            this.player.TabStop = false;
            // 
            // enemy
            // 
            this.enemy.Image = ((System.Drawing.Image)(resources.GetObject("enemy.Image")));
            this.enemy.Location = new System.Drawing.Point(765, 418);
            this.enemy.Name = "enemy";
            this.enemy.Size = new System.Drawing.Size(32, 32);
            this.enemy.TabIndex = 1;
            this.enemy.TabStop = false;
            // 
            // jumpTimer
            // 
            this.jumpTimer.Enabled = true;
            // 
            // goodie
            // 
            this.goodie.Image = ((System.Drawing.Image)(resources.GetObject("goodie.Image")));
            this.goodie.Location = new System.Drawing.Point(674, 305);
            this.goodie.Name = "goodie";
            this.goodie.Size = new System.Drawing.Size(32, 32);
            this.goodie.TabIndex = 3;
            this.goodie.TabStop = false;
            // 
            // DisplayScore
            // 
            this.DisplayScore.AutoSize = true;
            this.DisplayScore.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.DisplayScore.Location = new System.Drawing.Point(626, 25);
            this.DisplayScore.Name = "DisplayScore";
            this.DisplayScore.Size = new System.Drawing.Size(55, 20);
            this.DisplayScore.TabIndex = 4;
            this.DisplayScore.Text = "Score:";
            // 
            // ScoreCollisionTimer
            // 
            this.ScoreCollisionTimer.Enabled = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.DisplayScore);
            this.Controls.Add(this.goodie);
            this.Controls.Add(this.player);
            this.Controls.Add(this.enemy);
            this.Controls.Add(this.background);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.background)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goodie)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer enemyTimer;
        private System.Windows.Forms.PictureBox background;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.PictureBox enemy;
        private System.Windows.Forms.Timer jumpTimer;
        private System.Windows.Forms.PictureBox goodie;
        private System.Windows.Forms.Label DisplayScore;
        private System.Windows.Forms.Timer ScoreCollisionTimer;
    }
}

