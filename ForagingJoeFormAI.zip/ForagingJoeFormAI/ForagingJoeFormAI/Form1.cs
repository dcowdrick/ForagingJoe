﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ForagingJoeFormAI
{
    public partial class Form1 : Form
    {
        // code from https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.picturebox.image?view=netframework-4.7.2

        // declare variables
        bool reverseDirection = false;
        bool gameOver = false;

        public Form1()
        {
            InitializeComponent();
            KeyDown += new KeyEventHandler(Form1_KeyDown);
            InitializeTimer();
        }
        

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (!gameOver)
            {
                // code from https://social.msdn.microsoft.com/Forums/vstudio/en-US/767a9ba6-e8d4-4112-bf2a-edadfaf75e70/c-moving-an-image?forum=csharpgeneral
                int x = pictureBox2.Location.X;
                int y = pictureBox2.Location.Y;
                //int jumpx = pictureBox1.Location.X;
                int jumpy = pictureBox2.Location.Y;

                if (e.KeyCode == Keys.Right) x += 5;
                else if (e.KeyCode == Keys.Left) x -= 5;
                else if (e.KeyCode == Keys.Up) y -= 5;
                else if (e.KeyCode == Keys.Down) y += 5;
                //else if (e.KeyCode == Keys.Space) jumpy -= 35; jumpy += 50;

                pictureBox2.Location = new Point(x, y);
            }
        }

        private void InitializeTimer()
        {
            timer1.Interval = 100;
            timer1.Tick += new EventHandler(Timer1_Tick);

            // Enable timer.  
            timer1.Enabled = true;
        }

        private void Timer1_Tick(object Sender, EventArgs e)
        {
            if (!gameOver)
            {
                var playerPosX = pictureBox2.Location.X;
                var playerPosY = pictureBox2.Location.Y;
                var enemyPosX = pictureBox1.Location.X;
                var enemyPosY = pictureBox1.Location.Y;
                var distanceToPlayer = ((playerPosX - enemyPosX) * (playerPosX - enemyPosX) + (playerPosY - enemyPosY) * (playerPosY - enemyPosY));

                // Check distance to player
                // Show player lost
                if (distanceToPlayer <= 400 && !gameOver)
                {
                    // code from https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.messagebox?view=netframework-4.7.2
                    gameOver = true;
                    string message = "You died!";
                    string caption = "Game Over!";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult result;

                    // Displays the MessageBox.

                    result = MessageBox.Show(message, caption, buttons);

                    if (result == System.Windows.Forms.DialogResult.OK)
                    {

                        // Closes the parent form.

                        this.Close();

                    }
                }

                if (!reverseDirection)
                {
                    pictureBox1.Left -= 5;
                }
                else if (reverseDirection)
                {
                    pictureBox1.Left += 5;
                }

                if (!reverseDirection && pictureBox1.Left <= 5)
                {
                    reverseDirection = true;
                }
                else if (reverseDirection && pictureBox1.Left >= 480)
                {
                    reverseDirection = false;
                }
            }
        }

        //private void TranslateImageTopToX(PictureBox actor)
        //{
        //    int imgWidth = actor.Image.Width;
        //    int imgHeight = actor.Image.Height;
        //    int boxWidth = actor.Size.Width;
        //    int boxHeight = actor.Size.Height;

        //    //This variable will hold the result
        //    float X = e.X;
        //    float Y = e.Y;
        //    //Comparing the aspect ratio of both the control and the image itself.
        //    if (imgWidth / imgHeight > boxWidth / boxHeight)
        //    {
        //        //If true, that means that the image is stretched through the width of the control.
        //        //'In other words: the image is limited by the width.

        //        //The scale of the image in the Picture Box.
        //        float scale = boxWidth / imgWidth;

        //        //Since the image is in the middle, this code is used to determinate the empty space in the height
        //        //'by getting the difference between the box height and the image actual displayed height and dividing it by 2.
        //        float blankPart = (boxHeight - scale * imgHeight) / 2;

        //        Y -= blankPart;

        //        //Scaling the results.
        //        X /= scale;
        //        Y /= scale;
        //    }
        //    else
        //    {
        //        //If true, that means that the image is stretched through the height of the control.
        //        //'In other words: the image is limited by the height.

        //        //The scale of the image in the Picture Box.
        //        float scale = boxHeight / imgHeight;

        //        //Since the image is in the middle, this code is used to determinate the empty space in the width
        //        //'by getting the difference between the box width and the image actual displayed width and dividing it by 2.
        //        float blankPart = (boxWidth - scale * imgWidth) / 2;
        //        X -= blankPart;

        //        //Scaling the results.
        //        X /= scale;
        //        Y /= scale;
        //    }
        //}
    }

        // Main character class
    //class AI : Form1
    //{
      
    //}
    //{
    //    PictureBox pictureBox1 = new PictureBox();

    //    public AI()
    //    {
    //        InitializeComponent();
    //    }

    //    public void CreateActor()
    //    {
            
    //        Controls.Add(pictureBox1);
    //        pictureBox1.Size = new Size(640, 480);
    //        Bitmap actor = new Bitmap(32, 32);
    //        Graphics actorGraphics = Graphics.FromImage(actor);

    //        actorGraphics.FillRectangle(Brushes.Red, 0, 0, 32, 32);
    //        pictureBox1.Image = actor;
    //    }
    //}

        //public class Player : AI
        //{
        //    public Player()
        //    {

        //    }
        //}

        //public class EnemyAI : AI
        //{

        //}

        //public class FriendlyAI : AI
        //{

        //}
    }
