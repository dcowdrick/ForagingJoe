﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Media;

namespace ForagingJoe
{
    public class GameState
    {
         

    
    // The main game state.

    private const int _initialLives = 3;

        Score currentGameScore = new Score("", 0);
        public int Lives;
        public States State = States.Starting;
        public SizeF GameArea;
        public List<GameObject> GameObjects = new List<GameObject>();
        private Player _player;

        //example of sound, change later

        //private SoundPlayer _dead = new SoundPlayer(@"sounds\dead.wav");

        private Font _font = new Font("Arial", 24);
        private Brush _brush = new SolidBrush(Color.White);
        private static Random _random = new Random();

        public GameState(SizeF gameArea)
        {
            GameArea = gameArea;

            // sounds have to be loaded
            //_dead.Load();
        }

        public void Draw(Graphics graphics)
        {
            foreach (GameObject gameObject in GameObjects)
            {
                gameObject.Draw(graphics);
            }

            if (State != States.Playing)
            {
                graphics.DrawString("Press any Key to play", _font, _brush, 240, 300);
            }

            if (State == States.GameOver)
            {
                graphics.DrawString("GAME OVER", _font, _brush, 300, 260);
            }

            //Score goes on the right hand side of the screen so calculate the correct position by measuring the string
            graphics.DrawString(currentGameScore.ToString(), _font, _brush, GameArea.Width - graphics.MeasureString(currentGameScore.ToString(), _font).Width, 0);

            //Number of lives left
            graphics.DrawString("x " + Lives.ToString(), _font, _brush, 40, 0);
        }

        public void Update(double gameTime, double elapsedTime)
        {
            //Updates all the game stuff
            if (State == States.Playing)
            {
                //Create or destroy any transient objects


                foreach (GameObject gameObject in GameObjects)
                {
                    gameObject.Update(gameTime, elapsedTime);
                }


                //Check for any collisions

                
            }
        }

        // put collision functions here







        public void Initialize()
        {
            //Create all of the objects
            GameObjects.Clear();

            // Spawn the player at this position
            _player = new Player(this, GameArea.Width / 6 - 20, GameArea.Height - 46);
            GameObjects.Add(_player);

            // Lives sprite
            GameObjects.Add(new Sprite(this, 0, 0, @"graphics\Player.bmp"));

            //Reset the game state
            currentGameScore.setCurrentScore(0);
            Lives = _initialLives;
            //any other variables that need to be reset, place here



        }
    }
    public class ScoreBoard
    {
        private int _numScores;
        protected List<Score> displayBoard;

        public ScoreBoard(int numScores, List<Score> displayBoard)
        {
            setNumScore();
            createBoard();

        }
        //we decided our scoreboard will display 10 top scores
        private void setNumScore()
        {
            _numScores = 10;
        }
        //method to creat the actual scoreboard to be displayed
        protected void createBoard()
        {
            List<Score> board = new List<Score>(_numScores);

        }
        protected void addScore(Score currentScore, List<Score> currentBoard)
        {
            currentBoard.Add(currentScore);
            currentBoard.Sort((a, b) => a.getScoreValue().CompareTo(b.getScoreValue()));
            currentBoard.RemoveAt(_numScores);
        }
    }
    public class Score
    {
        protected String mName;
        protected int mScoreValue;

        public Score(String user, int currentScore)
        {
            setName(user);
            setCurrentScore(currentScore);
        }
        public void setName(String name)
        {
            mName.Equals(name);
        }
        public void setCurrentScore(int scoreValue)
        {
            mScoreValue = scoreValue;
        }
        public int getScoreValue()
        {
            return mScoreValue;
        }
        public String getName()
        {
            return mName;
        }
        public bool equals(String user, int currentScore, Score scoreInQuestion)
        {
            if (scoreInQuestion.getName().Equals(user) && scoreInQuestion.getScoreValue() == currentScore)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override string ToString()
        {
            return ("User " + mName + " has a score of " + mScoreValue);
        }
    }



    public enum States
    {
        Starting,
        Playing,
        GameOver,
    }
}