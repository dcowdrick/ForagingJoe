﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ForagingJoe
{
    public class Player : Sprite
    {
        public const string _playerBitmap = @"graphics\Player.bmp";
        private const double _speed = 150;
        private const bool _verticalMovement = false;

        public Player(GameState gameState, float x, float y)
            :base(gameState, x, y, _playerBitmap)
        {
        }

        public override void Update(double gameTime, double elapsedTime)
        {
            double velocity = 0.0;
            //Set the velocity of the sprite based on which keys are pressed
            if (Keyboard.Left)
            {
                velocity += -_speed;
            }
            if (Keyboard.Right)
            {
                velocity += _speed;
            }
            if (Keyboard.Up && _verticalMovement)
            {
                velocity += -_speed;
            }
            if (Keyboard.Down && _verticalMovement)
            {
                velocity += _speed;
            }

            if (Keyboard.Left || Keyboard.Right)
            {
                Velocity.X = (float)velocity;
            }
            if ((Keyboard.Up || Keyboard.Down) && _verticalMovement)
            {
                Velocity.Y = (float)velocity;
            }
            // Stops the player after the keys are released
            if (!Keyboard.Left && !Keyboard.Right)
            {
                Velocity.X = (float)velocity;
            }
            if ((!Keyboard.Up && !Keyboard.Down) && _verticalMovement)
            {
                Velocity.Y = (float)velocity;
            }
            

            //Perform any animation
            base.Update(gameTime, elapsedTime);

            //Limit the animation to the screen
            if (Location.X < 0) Location.X = 0;
            if (Location.X > _gameState.GameArea.Width - Size.Width) Location.X = _gameState.GameArea.Width - Size.Width;
        }
    }
}