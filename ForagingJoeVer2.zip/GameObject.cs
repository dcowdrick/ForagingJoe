﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace ForagingJoe
{
    // The game object class should be as abstract as possible as it can be many different things.
    public abstract class GameObject
    {
        public abstract void Update(double gameTime, double deltaTime);
        public abstract void Draw(Graphics graphics);
    }
}