﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Media;

namespace ForagingJoe
{
    public class GameState
    {
        // The main game state.

        private const int _initialLives = 3;

        public int Score;
        public int Lives;
        public States State = States.Starting;
        public SizeF GameArea;
        // get a list of game objects in the game
        public List<GameObject> GameObjects = new List<GameObject>();
        private Player _player;
        private Enemy _enemies;
        private Platform _platforms;
        public double gravity = 150.0;

        //example of sound, change later

        //private SoundPlayer _dead = new SoundPlayer(@"sounds\dead.wav");
        
        // set fonts and colors for text in game
        private Font _font = new Font("Arial", 24);
        private Brush _brush = new SolidBrush(Color.White);
        // get a random number 
        private static Random _random = new Random();

        // constructor, gets the game area
        public GameState(SizeF gameArea)
        {
            GameArea = gameArea;

            // sounds have to be loaded
            //_dead.Load();
        }

        public void Draw(Graphics graphics)
        {
            // we do a foreach loop with our game object list and draw the objects
            foreach (GameObject gameObject in GameObjects)
            {
                gameObject.Draw(graphics);
            }

            if (State != States.Playing)
            {
                graphics.DrawString("Press any Key to play", _font, _brush, 240, 300);
            }

            if (State == States.GameOver)
            {
                graphics.DrawString("GAME OVER", _font, _brush, 300, 260);
            }

            //Score goes on the right hand side of the screen so calculate the correct position by measuring the string
            graphics.DrawString(Score.ToString(), _font, _brush, GameArea.Width - graphics.MeasureString(Score.ToString(), _font).Width, 0);

            //Number of lives left
            graphics.DrawString("x " + Lives.ToString(), _font, _brush, 40, 0);
        }

        public void Update(double gameTime, double elapsedTime)
        {
            //Updates all the game stuff
            if (State == States.Playing)
            {
                //Create or destroy any temporary objects

                // update each object
                foreach (GameObject gameObject in GameObjects)
                {
                    gameObject.Update(gameTime, elapsedTime);
                }

                checkPlayerCollisions();
            }
        }

        private void checkPlayerCollisions()
        {
            Sprite entityHit = _player.CheckCollisions();
            if (entityHit is EnemySprite)
            {
                if (Lives == 0)
                {
                    State = States.GameOver;
                }
                else
                {
                    Lives--;
                    SoftReset();
                }
            }
            else if (entityHit is PlatformSprite)
            {
                //_player.Velocity.X = -_player.Velocity.X;
                //_player.Velocity.Y = -_player.Velocity.Y;
                //_player.speed = 0;
                //_player.collidedWithPlatform = true;
            }
        }

        public void Initialize()
        {
            //Clear the game objects list
            GameObjects.Clear();

            // Spawn the player at this position
            _player = new Player(this, GameArea.Width / 6 - 20, GameArea.Height - 46);
            // add the new player object to the game objects list
            GameObjects.Add(_player);

            // Spawn enemy
            _enemies = new Enemy(this);
            GameObjects.Add(_enemies);

            // Spawn test platform
            _platforms = new Platform(this);
            GameObjects.Add(_platforms);

            // Lives sprite, add it to the game objects list
            GameObjects.Add(new Sprite(this, 0, 0, @"graphics\Player.bmp"));

            //Reset the game state
            Score = 0;
            Lives = _initialLives;
            
        }

        private void SoftReset()
        {
            //Clear the game objects list
            GameObjects.Clear();

            // Spawn the player at this position
            _player = new Player(this, GameArea.Width / 6 - 20, GameArea.Height - 46);
            // add the new player object to the game objects list
            GameObjects.Add(_player);

            // Spawn enemy
            _enemies = new Enemy(this);
            GameObjects.Add(_enemies);

            // Spawn test platform
            _platforms = new Platform(this);
            GameObjects.Add(_platforms);

            // Lives sprite, add it to the game objects list
            GameObjects.Add(new Sprite(this, 0, 0, @"graphics\Player.bmp"));
        }
    }



    public enum States
    {
        Starting,
        Playing,
        GameOver,
    }
}